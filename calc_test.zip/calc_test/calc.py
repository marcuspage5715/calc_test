#!/usr/bin/env python3
"""A small, safe command line calculator built for Termux.

Type an expression and press Enter. Nothing in the input is ever passed to
eval(); the expression is parsed into a syntax tree and only a fixed set of
node types and functions is allowed through.
"""

from __future__ import annotations

import ast
import math
import sys

__version__ = "1.0.0"

MAX_INPUT_CHARS = 1000
MAX_EXPONENT = 1000
MAX_FACTORIAL = 1000

BIN_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a**b,
}

UNARY_OPS = {
    ast.UAdd: lambda a: +a,
    ast.USub: lambda a: -a,
}

CONSTANTS = {"pi": math.pi, "e": math.e, "tau": math.tau}


class CalcError(Exception):
    """Raised when an expression is invalid or cannot be evaluated."""


def format_number(value):
    """Render a result the way a person would write it."""
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int):
        return str(value)
    if math.isnan(value):
        return "nan"
    if math.isinf(value):
        return "inf" if value > 0 else "-inf"
    if value == 0:
        return "0"
    if float(value).is_integer() and abs(value) < 1e16:
        return str(int(value))
    return f"{value:.12g}"


class Evaluator:
    """Evaluates arithmetic expressions safely."""

    def __init__(self, degrees=False):
        self.degrees = degrees
        self.ans = 0

    # -- public entry point ------------------------------------------------
    def evaluate(self, expression):
        expression = expression.strip()
        if not expression:
            raise CalcError("Nothing to calculate.")
        if len(expression) > MAX_INPUT_CHARS:
            raise CalcError(f"Expression is too long (limit {MAX_INPUT_CHARS} characters).")

        # "^" means power here, but Python reads it as bitwise xor, so try the
        # rewritten form first and fall back to the input as typed.
        candidates = []
        if "^" in expression:
            candidates.append(expression.replace("^", "**"))
        candidates.append(expression)

        tree = None
        for candidate in candidates:
            try:
                tree = ast.parse(candidate, mode="eval")
                break
            except SyntaxError as exc:
                last_error = exc
        if tree is None:
            raise CalcError(f"Invalid expression: {last_error.msg}")

        result = self._eval(tree.body)
        self.ans = result
        return result

    # -- tree walking ------------------------------------------------------
    def _eval(self, node):
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
                raise CalcError("Only numbers are allowed.")
            return node.value

        if isinstance(node, ast.Name):
            if node.id == "ans":
                return self.ans
            if node.id in CONSTANTS:
                return CONSTANTS[node.id]
            raise CalcError(f"Unknown name '{node.id}'. Type help for what is available.")

        if isinstance(node, ast.BinOp):
            op = BIN_OPS.get(type(node.op))
            if op is None:
                raise CalcError("That operator is not supported.")
            left = self._eval(node.left)
            right = self._eval(node.right)
            self._guard(node.op, left, right)
            try:
                return op(left, right)
            except ZeroDivisionError:
                raise CalcError("Division by zero.") from None
            except (OverflowError, ValueError) as exc:
                raise CalcError(f"Could not compute that: {exc}") from None

        if isinstance(node, ast.UnaryOp):
            op = UNARY_OPS.get(type(node.op))
            if op is None:
                raise CalcError("That operator is not supported.")
            return op(self._eval(node.operand))

        if isinstance(node, ast.Call):
            return self._call(node)

        raise CalcError("That kind of expression is not supported.")

    def _guard(self, op, left, right):
        if isinstance(op, ast.Pow) and abs(right) > MAX_EXPONENT:
            raise CalcError(f"Exponent is too large (limit {MAX_EXPONENT}).")

    def _call(self, node):
        if not isinstance(node.func, ast.Name):
            raise CalcError("Only named functions can be called.")
        name = node.func.id
        if node.keywords:
            raise CalcError("Keyword arguments are not supported.")

        args = [self._eval(arg) for arg in node.args]
        func = self._lookup(name, args)

        try:
            return func(*args)
        except ZeroDivisionError:
            raise CalcError("Division by zero.") from None
        except (ValueError, TypeError) as exc:
            raise CalcError(f"{name}(): {exc}") from None
        except OverflowError:
            raise CalcError(f"{name}(): result is too large.") from None

    def _lookup(self, name, args):
        def arity(count):
            if len(args) != count:
                plural = "s" if count != 1 else ""
                raise CalcError(f"{name}() takes {count} argument{plural}, got {len(args)}.")

        if name == "sqrt":
            arity(1)
            return math.sqrt
        if name == "abs":
            arity(1)
            return abs
        if name == "round":
            if len(args) not in (1, 2):
                raise CalcError("round() takes 1 or 2 arguments.")
            return round
        if name == "floor":
            arity(1)
            return math.floor
        if name == "ceil":
            arity(1)
            return math.ceil
        if name == "exp":
            arity(1)
            return math.exp
        if name == "ln":
            arity(1)
            return math.log
        if name == "log":
            if len(args) == 1:
                return math.log10
            arity(2)
            return math.log
        if name == "log2":
            arity(1)
            return math.log2
        if name == "factorial":
            arity(1)
            if args[0] > MAX_FACTORIAL:
                raise CalcError(f"factorial() is limited to {MAX_FACTORIAL}.")
            return math.factorial
        if name == "pow":
            arity(2)
            if abs(args[1]) > MAX_EXPONENT:
                raise CalcError(f"Exponent is too large (limit {MAX_EXPONENT}).")
            return math.pow
        if name in ("min", "max"):
            if not args:
                raise CalcError(f"{name}() needs at least one argument.")
            return min if name == "min" else max
        if name in ("sin", "cos", "tan", "asin", "acos", "atan"):
            arity(1)
            return self._trig(name)
        raise CalcError(f"Unknown function '{name}'. Type help to see the list.")

    def _trig(self, name):
        base = getattr(math, name)
        to_radians = math.radians
        from_radians = math.degrees

        if name in ("sin", "cos", "tan"):
            if self.degrees:
                return lambda x: base(to_radians(x))
            return base

        if self.degrees:
            return lambda x: from_radians(base(x))
        return base


BANNER = f"""Termux calculator {__version__}
Type an expression, e.g. 2+3*4, sqrt(2), or 15% of 200 as 200*0.15.
Commands: help, deg, rad, clear, quit"""

HELP = """Commands
  help            show this text
  deg / rad       switch trigonometry between degrees and radians
  clear           clear the screen
  quit            leave (q, exit and Ctrl-D also work)

Operators
  + - * /         arithmetic
  // %            floor division, remainder
  ** or ^         power
  ( )             grouping
  -x              negative numbers

Constants   pi, e, tau, ans (the previous result)

Functions
  sqrt(x)  abs(x)  round(x[, n])  floor(x)  ceil(x)
  exp(x)  ln(x)  log(x)  log(x, base)  log2(x)
  factorial(n)  pow(x, y)  min(...)  max(...)
  sin(x)  cos(x)  tan(x)  asin(x)  acos(x)  atan(x)"""


class Colors:
    def __init__(self, enabled):
        self.enabled = enabled

    def _wrap(self, code, text):
        return f"\033[{code}m{text}\033[0m" if self.enabled else text

    def red(self, text):
        return self._wrap("31", text)

    def green(self, text):
        return self._wrap("32", text)

    def cyan(self, text):
        return self._wrap("36", text)

    def dim(self, text):
        return self._wrap("2", text)


def run_expression(evaluator, colors, expression):
    """Evaluate one expression and print it. Returns True on success."""
    try:
        result = evaluator.evaluate(expression)
    except CalcError as exc:
        print(colors.red(f"Error: {exc}"))
        return False
    except RecursionError:
        print(colors.red("Error: expression is too deeply nested."))
        return False
    print(colors.green(format_number(result)))
    return True


def repl(evaluator, colors):
    print(colors.cyan(BANNER))
    while True:
        try:
            line = input(colors.cyan("> "))
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        command = line.strip().lower()

        if command in ("quit", "exit", "q"):
            return 0
        if command in ("help", "h", "?"):
            print(colors.dim(HELP))
            continue
        if command == "clear":
            print("\033[H\033[2J", end="")
            continue
        if command in ("deg", "degrees"):
            evaluator.degrees = True
            print(colors.dim("Trigonometry in degrees."))
            continue
        if command in ("rad", "radians"):
            evaluator.degrees = False
            print(colors.dim("Trigonometry in radians."))
            continue
        if not command:
            continue

        run_expression(evaluator, colors, line)


def main(argv):
    colors = Colors(sys.stdout.isatty())

    if len(argv) > 1:
        # One-shot mode: python calc.py "2+2" prints 4 and exits.
        expression = " ".join(argv[1:])
        return 0 if run_expression(Evaluator(), colors, expression) else 1

    try:
        return repl(Evaluator(), colors)
    except KeyboardInterrupt:
        print()
        return 130


if __name__ == "__main__":
    sys.exit(main(sys.argv))
