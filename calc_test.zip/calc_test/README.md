# calc_test

A small command line calculator written for [Termux](https://termux.dev) on Android. Pure Python 3, no dependencies.

![screenshot placeholder](https://img.shields.io/badge/python-3.8%2B-blue)

## Features

- Type a whole expression at once: `2+3*4`, `(1+2)/3`, `2^10`
- Real functions: `sqrt`, `ln`, `log`, `log2`, `exp`, `factorial`, `round`, `floor`, `ceil`, `min`, `max`, and trigonometry
- `pi`, `e`, `tau` constants, plus `ans` for the previous result
- Degrees or radians with `deg` / `rad`
- Safe by design: input is parsed into a syntax tree, never passed to `eval()`. `__import__('os')`, attribute access, lists and assignments are all rejected
- One-shot mode so it works in scripts: `python calc.py "6*7"` prints `42`
- Guards against runaway input: exponent and factorial limits, input length limit

## Install on Termux

```bash
pkg install python -y
git clone https://github.com/marcuspage5715/calc_test
cd calc_test
chmod +x calc
./calc
```

Or copy the folder anywhere and run `python calc.py`.

## Usage

Interactive:

```
$ ./calc
Termux calculator 1.0.0
Type an expression, e.g. 2+3*4, sqrt(2), or 15% of 200 as 200*0.15.
Commands: help, deg, rad, clear, quit
> 2+3*4
14
> ans*2
28
> sqrt(2)
1.41421356237
> deg
Trigonometry in degrees.
> sin(90)
1
```

One-shot:

```bash
$ python calc.py "(12+8)/5"
4
$ python calc.py "factorial(10)"
3628800
```

## Commands

| Command | Effect |
| --- | --- |
| `help` | show operators, constants and functions |
| `deg` / `rad` | switch trigonometry between degrees and radians |
| `clear` | clear the screen |
| `quit` | exit (`q`, `exit`, `Ctrl-D` also work) |

## Operators

`+` `-` `*` `/` `//` `%` `**` (or `^`) and parentheses. `^` is treated as power, so `2^10` is `1024` and `2^3^2` is `512`.

## Tests

```bash
python -m unittest discover -s tests -v
```

20 tests covering arithmetic, precedence, functions, error handling, injection attempts, output formatting and the command line mode.

## Limits

- Exponents above 1000 are refused, as are factorials above 1000
- Expressions longer than 1000 characters are refused
- Integer division by zero and modulo by zero raise a clear error rather than a traceback

## License

GNU General Public License v3.0. See [LICENSE](LICENSE).
