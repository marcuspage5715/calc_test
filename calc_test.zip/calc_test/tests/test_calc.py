#!/usr/bin/env python3
"""Tests for the Termux calculator. Run: python -m unittest discover -s tests"""

import math
import os
import subprocess
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from calc import CalcError, Evaluator, format_number  # noqa: E402

CALC_PY = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "calc.py")


class ArithmeticTests(unittest.TestCase):
    def setUp(self):
        self.ev = Evaluator()

    def check(self, expression, expected):
        self.assertAlmostEqual(self.ev.evaluate(expression), expected, places=9)

    def test_basic_operations(self):
        self.check("2+2", 4)
        self.check("10-3", 7)
        self.check("6*7", 42)
        self.check("9/2", 4.5)
        self.check("9//2", 4)
        self.check("9%2", 1)

    def test_precedence_and_grouping(self):
        self.check("2+3*4", 14)
        self.check("(2+3)*4", 20)
        self.check("2*(3+(4-1))", 12)

    def test_powers(self):
        self.check("2**10", 1024)
        self.check("2^10", 1024)
        self.check("2^3^2", 512)
        self.check("-2**2", -4)

    def test_unary_and_decimals(self):
        self.check("-5+10", 5)
        self.check("+7", 7)
        self.check("0.1+0.2", 0.3)

    def test_constants(self):
        self.check("pi", math.pi)
        self.check("e", math.e)
        self.check("tau", math.tau)


class FunctionTests(unittest.TestCase):
    def setUp(self):
        self.ev = Evaluator()

    def test_functions(self):
        self.assertAlmostEqual(self.ev.evaluate("sqrt(16)"), 4)
        self.assertAlmostEqual(self.ev.evaluate("abs(-3)"), 3)
        self.assertAlmostEqual(self.ev.evaluate("round(3.14159, 2)"), 3.14)
        self.assertAlmostEqual(self.ev.evaluate("factorial(5)"), 120)
        self.assertAlmostEqual(self.ev.evaluate("log(1000)"), 3)
        self.assertAlmostEqual(self.ev.evaluate("log(8, 2)"), 3)
        self.assertAlmostEqual(self.ev.evaluate("ln(e)"), 1)
        self.assertAlmostEqual(self.ev.evaluate("min(3, 1, 2)"), 1)
        self.assertAlmostEqual(self.ev.evaluate("max(3, 1, 2)"), 3)

    def test_degrees_and_radians(self):
        self.assertAlmostEqual(self.ev.evaluate("sin(0)"), 0)
        self.ev.degrees = True
        self.assertAlmostEqual(self.ev.evaluate("sin(90)"), 1)
        self.assertAlmostEqual(self.ev.evaluate("cos(180)"), -1)
        self.assertAlmostEqual(self.ev.evaluate("asin(1)"), 90)

    def test_ans_carries_previous_result(self):
        self.ev.evaluate("7*6")
        self.assertAlmostEqual(self.ev.evaluate("ans+8"), 50)


class ErrorTests(unittest.TestCase):
    def setUp(self):
        self.ev = Evaluator()

    def assertRejected(self, expression):
        with self.assertRaises(CalcError):
            self.ev.evaluate(expression)

    def test_division_by_zero(self):
        self.assertRejected("1/0")
        self.assertRejected("1%0")

    def test_unknown_names_and_functions(self):
        self.assertRejected("nope")
        self.assertRejected("foo(1)")

    def test_wrong_arity(self):
        self.assertRejected("sqrt()")
        self.assertRejected("sqrt(1, 2)")

    def test_code_injection_is_blocked(self):
        for payload in [
            "__import__('os').system('echo hi')",
            "open('/etc/passwd').read()",
            "[1, 2, 3]",
            "{'a': 1}",
            "'abc'",
            "x = 1",
            "(lambda: 1)()",
            "eval('1+1')",
        ]:
            with self.subTest(payload=payload):
                self.assertRejected(payload)

    def test_limits(self):
        self.assertRejected("2**100000")
        self.assertRejected("factorial(5000)")
        self.assertRejected("1+" * 600)

    def test_empty_input(self):
        self.assertRejected("   ")

    def test_syntax_error_message(self):
        with self.assertRaises(CalcError):
            self.ev.evaluate("2+")


class FormattingTests(unittest.TestCase):
    def test_whole_numbers_have_no_decimal_point(self):
        self.assertEqual(format_number(4.0), "4")
        self.assertEqual(format_number(1024), "1024")

    def test_decimals_are_trimmed(self):
        self.assertEqual(format_number(4.5), "4.5")
        self.assertEqual(format_number(1 / 3), "0.333333333333")

    def test_special_values(self):
        self.assertEqual(format_number(math.inf), "inf")
        self.assertEqual(format_number(-math.inf), "-inf")
        self.assertEqual(format_number(math.nan), "nan")


class CommandLineTests(unittest.TestCase):
    def run_calc(self, *args):
        return subprocess.run(
            [sys.executable, CALC_PY, *args],
            capture_output=True,
            text=True,
            timeout=30,
        )

    def test_one_shot_prints_result(self):
        result = self.run_calc("6*7")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "42")

    def test_one_shot_error_exits_nonzero(self):
        result = self.run_calc("1/0")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Error", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
